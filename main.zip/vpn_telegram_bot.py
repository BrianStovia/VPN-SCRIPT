#!/usr/bin/env python3
import sys
import os
import subprocess

def main():
    for bot_bin in ["/usr/bin/vpn-bot", "/usr/local/sbin/vpn-bot"]:
        if os.path.exists(bot_bin) and os.access(bot_bin, os.X_OK):
            sys.exit(subprocess.call([bot_bin] + sys.argv[1:]))

    print("Error: /usr/bin/vpn-bot binary not found!")
    sys.exit(1)

if __name__ == "__main__":
    main()
