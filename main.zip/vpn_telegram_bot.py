#!/usr/bin/env bash
if [ -x "/usr/bin/vpn-bot" ]; then
    exec /usr/bin/vpn-bot "$@"
elif command -v vpn-bot &>/dev/null; then
    exec vpn-bot "$@"
else
    echo "Error: vpn-bot binary not found!"
    exit 1
fi
