#!/usr/bin/env python3
import sys
import os
import json
import subprocess

def find_json_array(text, key):
    idx = text.find(key)
    if idx == -1:
        return None, -1, -1
    start_bracket = text.find('[', idx)
    if start_bracket == -1:
        return None, -1, -1
    count = 0
    for i in range(start_bracket, len(text)):
        char = text[i]
        if char == '[':
            count += 1
        elif char == ']':
            count -= 1
            if count == 0:
                end_bracket = i
                return text[start_bracket:end_bracket+1], start_bracket, end_bracket+1
    return None, -1, -1

def main():
    if len(sys.argv) < 2:
        print("Usage: toggle_warp.py [enable|disable]")
        sys.exit(1)
        
    action = sys.argv[1].lower()
    
    # If native Go vpn-bot binary is available, delegate to it
    for bot_bin in ["/usr/bin/vpn-bot", "/usr/local/sbin/vpn-bot"]:
        if os.path.exists(bot_bin) and os.access(bot_bin, os.X_OK):
            sys.exit(subprocess.call([bot_bin, "toggle-warp", action]))

    config_path = "/usr/local/etc/v2ray/config.json"
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            text = f.read()
    except Exception as e:
        print(f"Error reading config: {e}")
        sys.exit(1)
        
    outbounds_str, start_out, end_out = find_json_array(text, '"outbounds":')
    if not outbounds_str:
        print("Error: Could not find outbounds array in config.json")
        sys.exit(1)
        
    rules_str, start_rules, end_rules = find_json_array(text, '"rules":')
    if not rules_str:
        print("Error: Could not find routing rules array in config.json")
        sys.exit(1)
        
    try:
        outbounds = json.loads(outbounds_str)
        rules = json.loads(rules_str)
    except Exception as e:
        print(f"Error parsing JSON components: {e}")
        sys.exit(1)
        
    if action == "enable":
        warp_outbound = {
            "protocol": "socks",
            "settings": {"servers": [{"address": "127.0.0.1", "port": 40000}]},
            "tag": "warp"
        }
        other_outbounds = [o for o in outbounds if o.get("tag") not in ("warp", "direct", "blocked")]
        direct_outbound = {"protocol": "freedom", "settings": {"domainStrategy": "UseIPv4"}, "tag": "direct"}
        blocked_outbound = {"protocol": "blackhole", "settings": {}, "tag": "blocked"}
        new_outbounds = [warp_outbound, direct_outbound, blocked_outbound] + other_outbounds
        new_rules = [r for r in rules if r.get("network") != "udp"]
        udp_rules = [
            {"type": "field", "port": "443", "network": "udp", "outboundTag": "blocked"},
            {"type": "field", "network": "udp", "outboundTag": "direct"}
        ]
        new_rules = udp_rules + new_rules
    elif action == "disable":
        other_outbounds = [o for o in outbounds if o.get("tag") not in ("warp", "direct", "blocked")]
        direct_outbound = {"protocol": "freedom", "settings": {"domainStrategy": "UseIPv4"}, "tag": "direct"}
        blocked_outbound = {"protocol": "blackhole", "settings": {}, "tag": "blocked"}
        new_outbounds = [direct_outbound, blocked_outbound] + other_outbounds
        new_rules = [r for r in rules if r.get("network") != "udp"]
    else:
        print(f"Unknown action: {action}")
        sys.exit(1)
        
    new_outbounds_str = json.dumps(new_outbounds, indent=2)
    new_rules_str = json.dumps(new_rules, indent=2)
    
    if start_out > start_rules:
        text = text[:start_out] + new_outbounds_str + text[end_out:]
        _, start_rules2, end_rules2 = find_json_array(text, '"rules":')
        text = text[:start_rules2] + new_rules_str + text[end_rules2:]
    else:
        text = text[:start_rules] + new_rules_str + text[end_rules:]
        _, start_out2, end_out2 = find_json_array(text, '"outbounds":')
        text = text[:start_out2] + new_outbounds_str + text[end_out2:]
        
    try:
        with open(config_path, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"Successfully toggled WARP to: {action}")
    except Exception as e:
        print(f"Error writing config: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
