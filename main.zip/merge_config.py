#!/usr/bin/env python3
import os
import sys
import subprocess

def extract_clients(filepath):
    vless, vmess, trojan, reality_vision, reality_grpc = {}, {}, {}, {}, {}
    if not os.path.exists(filepath):
        return vless, vmess, trojan, reality_vision, reality_grpc
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
    except Exception as e:
        print(f"Error reading backup config: {e}")
        return vless, vmess, trojan, reality_vision, reality_grpc

    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith("#&r "):
            if i + 1 < len(lines):
                if "xtls-rprx-vision" in lines[i+1]:
                    reality_vision[line] = [lines[i], lines[i+1]]
                else:
                    reality_grpc[line] = [lines[i], lines[i+1]]
            i += 2
        elif line.startswith("#& "):
            if i + 1 < len(lines):
                vless[line] = [lines[i], lines[i+1]]
            i += 2
        elif line.startswith("### "):
            if i + 1 < len(lines):
                vmess[line] = [lines[i], lines[i+1]]
            i += 2
        elif line.startswith("#! "):
            if i + 1 < len(lines):
                trojan[line] = [lines[i], lines[i+1]]
            i += 2
        else:
            i += 1

    if not reality_grpc and reality_vision:
        for tag, cl in reality_vision.items():
            g_line = cl[1].replace('"flow": "xtls-rprx-vision",', '').replace('"flow":"xtls-rprx-vision",', '')
            reality_grpc[tag] = [cl[0], g_line]
    elif not reality_vision and reality_grpc:
        for tag, cl in reality_grpc.items():
            v_line = cl[1]
            if "flow" not in v_line:
                v_line = v_line.replace(',"email"', ',"flow": "xtls-rprx-vision","email"')
            reality_vision[tag] = [cl[0], v_line]

    return vless, vmess, trojan, reality_vision, reality_grpc

def main():
    # If native Go vpn-bot binary is available, delegate to it
    for bot_bin in ["/usr/bin/vpn-bot", "/usr/local/sbin/vpn-bot"]:
        if os.path.exists(bot_bin) and os.access(bot_bin, os.X_OK):
            sys.exit(subprocess.call([bot_bin, "merge-config"] + sys.argv[1:]))

    # Fallback to Python merge logic for legacy updaters
    primary_bak = "/root/v2ray_backup_before_update.json"
    fallback_bak = "/usr/local/etc/v2ray/config.json.bak"
    new_path = "/usr/local/etc/v2ray/config.json"
    
    selected_bak = primary_bak if os.path.exists(primary_bak) else fallback_bak
    if not os.path.exists(selected_bak):
        print("No backup config found to merge.")
        return
        
    print(f"Merging existing accounts from {selected_bak} into the new configuration...")
    vless, vmess, trojan, reality_vision, reality_grpc = extract_clients(selected_bak)
    total_reality = len(reality_vision) or len(reality_grpc)
    total_clients = len(vless) + len(vmess) + len(trojan) + total_reality
    if total_clients == 0:
        print("No accounts to merge.")
        return
        
    try:
        with open(new_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
    except Exception as e:
        print(f"Error reading new config: {e}")
        return

    out_lines = []
    for line in lines:
        out_lines.append(line)
        stripped = line.strip()
        if stripped.endswith("#vless"):
            for client_lines in vless.values():
                out_lines.extend(client_lines)
        elif stripped.endswith("#vmess"):
            for client_lines in vmess.values():
                out_lines.extend(client_lines)
        elif stripped.endswith("#trojan"):
            for client_lines in trojan.values():
                out_lines.extend(client_lines)
        elif stripped.endswith("#reality"):
            for client_lines in reality_vision.values():
                out_lines.extend(client_lines)
        elif stripped.endswith("#realitygrpc"):
            for client_lines in reality_grpc.values():
                out_lines.extend(client_lines)
                
    try:
        with open(new_path, "w", encoding="utf-8", errors="ignore") as f:
            f.writelines(out_lines)
        print(f"Successfully merged {total_clients} accounts back into configuration.")
    except Exception as e:
        print(f"Failed to write merged config: {e}")

if __name__ == "__main__":
    main()
